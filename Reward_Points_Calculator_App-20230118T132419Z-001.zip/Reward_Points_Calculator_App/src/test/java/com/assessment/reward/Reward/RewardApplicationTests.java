package com.assessment.reward.Reward;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardApplicationTests {

	@Test
	void contextLoads() {
	}

}
