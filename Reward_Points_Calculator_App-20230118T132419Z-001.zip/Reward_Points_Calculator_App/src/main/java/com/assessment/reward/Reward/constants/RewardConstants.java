package com.assessment.reward.Reward.constants;

public class RewardConstants {
    public static int firstRewardLimit = 50;
    public static int secondRewardLimit = 100;
}